# DNS DR Control Panel

Web dashboard to switch 600+ DNS records between HO and DR IPs during DR drills.
Runs on your Windows PC (domain-joined). Team accesses via your PC's IP.

---

## Requirements

- Windows 10/11, domain-joined
- Python 3.9+ (https://python.org)
- DNS admin rights in Active Directory
- PowerShell 5.1+ (built into Windows)
- RSAT: DNS Server Tools installed

### Install RSAT DNS Tools (one-time, run as admin):
```powershell
Add-WindowsCapability -Online -Name Rsat.Dns.Tools~~~~0.0.1.0
```

---

## Setup & Run

1. Extract this folder to your PC, e.g. `C:\dns-dashboard\`
2. Double-click `START.bat`
3. Open browser: http://localhost:5000
4. Team access: http://YOUR-PC-IP:5000

---

## Load your 600 records

**Option A — CSV Import (recommended)**

Edit `sample_records.csv` with your actual records:

| Column      | Description                                      |
|-------------|--------------------------------------------------|
| app_name    | Display name e.g. `CoreBanking`                  |
| record_name | DNS hostname part e.g. `corebank`                |
| zone        | DNS zone e.g. `bank.local`                       |
| ho_ip       | Head office IP e.g. `10.1.1.10`                  |
| dr_ip       | DR site IP e.g. `10.99.1.10`                     |
| dns_server  | Leave blank to use global, or override per-record |

Then click **↑ Import CSV** in the dashboard.

**Option B — Add one by one** using the ＋ button.

---

## Running a DR drill

1. Enter your DNS server in the top field (e.g. `dc01.bank.local`)
2. Optionally select specific records (click to select) — or leave all unselected to change all
3. Click **⇒ DR** — review the confirmation dialog showing count
4. Confirm — watch the live progress table
5. After drill, click **⇐ HO** to roll back

---

## How it connects to the DNS server

Uses PowerShell's built-in `DnsServer` module with the `-ComputerName` parameter.
Since your PC is domain-joined, it uses your Windows login (Kerberos) — no passwords needed.

```powershell
# What runs under the hood per record:
Get-DnsServerResourceRecord -ComputerName "dc01.bank.local" -ZoneName "bank.local" -Name "corebank" -RRType A
Set-DnsServerResourceRecord -ComputerName "dc01.bank.local" ...
```

---

## Firewall / network

If you get connection errors, ask your network team to allow:
- Port **5985** (WinRM HTTP) from your PC to the DNS server
- Or port **5986** (WinRM HTTPS)

WinRM is usually already enabled on domain controllers.

---

## Files

```
dns-dashboard/
├── app.py              # Flask backend + DNS logic
├── requirements.txt    # Python dependencies (just Flask)
├── START.bat           # Double-click to run
├── sample_records.csv  # Template for bulk import
├── templates/
│   └── index.html      # Web dashboard
├── data/
│   └── dns_records.json  # Your loaded records (auto-created)
└── logs/
    └── change_history.json  # Audit log of all sessions
```

---

## Troubleshooting

| Error | Fix |
|-------|-----|
| `Access denied` | Run as your AD account with DNS admin rights |
| `RPC server unavailable` | WinRM not enabled on DNS server — enable with `Enable-PSRemoting -Force` on that server |
| `Record not found` | Check record_name and zone match exactly what's in DNS Manager |
| Port 5000 in use | Edit `app.py` last line — change `port=5000` to `port=5001` |
