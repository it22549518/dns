from flask import Flask, render_template, request, jsonify, send_file
import subprocess
import csv
import json
import os
import io
import threading
from datetime import datetime

app = Flask(__name__)

RECORDS_FILE = "data/dns_records.json"
CHANGE_LOG   = "logs/change_history.json"
DNS_SERVER   = "192.168.13.80"   # the remote Windows DNS server
BIND_HOST    = "127.0.0.1"       # dashboard only on localhost — not visible to others
BIND_PORT    = 5000

# Temp file that holds the DPAPI-encrypted PSCredential during a job.
# Only decryptable by the same Windows user on this machine.
CRED_CACHE_PS = r"$env:TEMP\dns_dr_cred.xml"

# ── helpers ───────────────────────────────────────────────────────────────────

def load_records():
    if not os.path.exists(RECORDS_FILE):
        return []
    with open(RECORDS_FILE) as f:
        return json.load(f)

def save_records(records):
    with open(RECORDS_FILE, "w") as f:
        json.dump(records, f, indent=2)

def load_change_log():
    if not os.path.exists(CHANGE_LOG):
        return []
    with open(CHANGE_LOG) as f:
        return json.load(f)

def append_change_log(entry):
    log = load_change_log()
    log.insert(0, entry)
    with open(CHANGE_LOG, "w") as f:
        json.dump(log[:500], f, indent=2)

# ── credential handling ───────────────────────────────────────────────────────
#
# Option B: Windows credential popup (Get-Credential).
# - Pops a real Windows dialog — password never touches Python or Flask.
# - PSCredential is encrypted with DPAPI and saved to a temp file.
# - Each DNS change loads that temp file to authenticate to 192.168.13.80.
# - Temp file is deleted when the job finishes or is aborted.
#
# The username is pre-filled as ".\user1" so the operator just enters
# the password and clicks OK.

def prompt_and_cache_credential():
    """
    Shows Windows credential dialog once per job.
    Saves encrypted credential to temp file.
    Returns (True, username) or (False, error_message).
    """
    ps = f"""
$ErrorActionPreference = 'Stop'
try {{
    $cred = Get-Credential -Message "Enter credentials for DNS server {DNS_SERVER}" -UserName ".\\user1"
    if (-not $cred) {{ Write-Output "CANCELLED"; exit 1 }}
    $cred | Export-Clixml -Path {CRED_CACHE_PS} -Force
    Write-Output "CRED_OK:$($cred.UserName)"
}} catch {{
    Write-Output "ERROR:$($_.Exception.Message)"
}}
"""
    try:
        result = subprocess.run(
            ["powershell", "-NoProfile", "-Command", ps],
            capture_output=True, text=True, timeout=120
        )
        out = (result.stdout + result.stderr).strip()
        if out.startswith("CRED_OK:"):
            return True, out.replace("CRED_OK:", "").strip()
        elif "CANCELLED" in out:
            return False, "Credential prompt was cancelled"
        else:
            return False, out.replace("ERROR:", "").strip() or "Credential prompt failed"
    except subprocess.TimeoutExpired:
        return False, "Timed out waiting for credential input (120s)"
    except Exception as e:
        return False, str(e)


def clear_credential_cache():
    """Delete the encrypted credential temp file."""
    ps = f"if (Test-Path {CRED_CACHE_PS}) {{ Remove-Item {CRED_CACHE_PS} -Force }}"
    try:
        subprocess.run(
            ["powershell", "-NoProfile", "-Command", ps],
            capture_output=True, timeout=10
        )
    except Exception:
        pass


def run_dns_change(zone, record_name, new_ip):
    """
    Loads the cached (DPAPI-encrypted) credential and uses Invoke-Command
    over WinRM to update one A record on 192.168.13.80.
    Password is never in plain text anywhere.
    """
    ps = f"""
$ErrorActionPreference = 'Stop'
try {{
    $cred = Import-Clixml -Path {CRED_CACHE_PS}
    $result = Invoke-Command -ComputerName '{DNS_SERVER}' -Credential $cred -ScriptBlock {{
        param($zone, $name, $newip)
        $ErrorActionPreference = 'Stop'
        $existing = Get-DnsServerResourceRecord -ZoneName $zone -Name $name -RRType A
        $updated  = $existing.Clone()
        $updated.RecordData.IPv4Address = [System.Net.IPAddress]::Parse($newip)
        Set-DnsServerResourceRecord -ZoneName $zone -OldInputObject $existing -NewInputObject $updated
        "SUCCESS"
    }} -ArgumentList '{zone}', '{record_name}', '{new_ip}'
    Write-Output $result
}} catch {{
    Write-Output "ERROR:$($_.Exception.Message)"
}}
"""
    try:
        result = subprocess.run(
            ["powershell", "-NoProfile", "-NonInteractive", "-Command", ps],
            capture_output=True, text=True, timeout=30
        )
        out = (result.stdout + result.stderr).strip()
        if "SUCCESS" in out:
            return True, "Updated successfully"
        elif "ERROR:" in out:
            return False, out.replace("ERROR:", "").strip()
        else:
            return False, out or "Unknown error"
    except subprocess.TimeoutExpired:
        return False, "Timeout — DNS server 192.168.13.80 did not respond in 30s"
    except Exception as e:
        return False, str(e)


# ── background job ────────────────────────────────────────────────────────────

job_state = {
    "running":     False,
    "direction":   None,
    "total":       0,
    "done":        0,
    "results":     [],
    "started_at":  None,
    "finished_at": None,
    "logged_user": None,
}
job_lock = threading.Lock()


def run_bulk_job(direction, records_to_change, logged_user):
    session_results = []

    for rec in records_to_change:
        with job_lock:
            if not job_state["running"]:
                break  # aborted

        target_ip = rec["dr_ip"] if direction == "DR" else rec["ho_ip"]
        from_ip   = rec["ho_ip"] if direction == "DR" else rec["dr_ip"]

        ok, msg = run_dns_change(
            zone        = rec["zone"],
            record_name = rec["record_name"],
            new_ip      = target_ip,
        )

        entry = {
            "app_name":    rec["app_name"],
            "record_name": rec["record_name"],
            "zone":        rec["zone"],
            "from_ip":     from_ip,
            "to_ip":       target_ip,
            "status":      "success" if ok else "failed",
            "message":     msg,
            "timestamp":   datetime.now().isoformat(),
        }
        session_results.append(entry)

        with job_lock:
            job_state["done"] += 1
            job_state["results"].append(entry)

    with job_lock:
        job_state["running"] = False
        job_state["finished_at"] = datetime.now().isoformat()

    clear_credential_cache()

    append_change_log({
        "session":    datetime.now().isoformat(),
        "direction":  direction,
        "dns_server": DNS_SERVER,
        "logged_as":  logged_user,
        "total":      len(records_to_change),
        "success":    sum(1 for r in session_results if r["status"] == "success"),
        "failed":     sum(1 for r in session_results if r["status"] == "failed"),
        "records":    session_results,
    })


# ── routes ────────────────────────────────────────────────────────────────────

@app.route("/")
def index():
    return render_template("index.html", dns_server=DNS_SERVER)

@app.route("/api/records", methods=["GET"])
def get_records():
    q = request.args.get("q", "").lower()
    records = load_records()
    if q:
        records = [r for r in records if
                   q in r["app_name"].lower() or
                   q in r["record_name"].lower() or
                   q in r["zone"].lower() or
                   q in r.get("ho_ip", "") or
                   q in r.get("dr_ip", "")]
    return jsonify(records)

@app.route("/api/records", methods=["POST"])
def add_record():
    data = request.json
    if not all(k in data for k in ["app_name", "record_name", "zone", "ho_ip", "dr_ip"]):
        return jsonify({"error": "Missing fields"}), 400
    records = load_records()
    data["id"] = datetime.now().timestamp()
    records.append(data)
    save_records(records)
    return jsonify({"ok": True})

@app.route("/api/records/<record_id>", methods=["DELETE"])
def delete_record(record_id):
    records = [r for r in load_records() if str(r.get("id")) != record_id]
    save_records(records)
    return jsonify({"ok": True})

@app.route("/api/records/import", methods=["POST"])
def import_csv():
    f = request.files.get("file")
    if not f:
        return jsonify({"error": "No file"}), 400
    stream = io.StringIO(f.stream.read().decode("utf-8"))
    reader = csv.DictReader(stream)
    records = load_records()
    added, errors = 0, []
    for i, row in enumerate(reader, 1):
        try:
            records.append({
                "id":          datetime.now().timestamp() + i,
                "app_name":    row["app_name"].strip(),
                "record_name": row["record_name"].strip(),
                "zone":        row["zone"].strip(),
                "ho_ip":       row["ho_ip"].strip(),
                "dr_ip":       row["dr_ip"].strip(),
            })
            added += 1
        except Exception as e:
            errors.append(f"Row {i}: {e}")
    save_records(records)
    return jsonify({"added": added, "errors": errors})

@app.route("/api/records/export", methods=["GET"])
def export_csv():
    records = load_records()
    si = io.StringIO()
    w = csv.DictWriter(si, fieldnames=["app_name", "record_name", "zone", "ho_ip", "dr_ip"])
    w.writeheader()
    for r in records:
        w.writerow({k: r.get(k, "") for k in ["app_name", "record_name", "zone", "ho_ip", "dr_ip"]})
    out = io.BytesIO(si.getvalue().encode())
    out.seek(0)
    return send_file(out, mimetype="text/csv", download_name="dns_records.csv", as_attachment=True)

@app.route("/api/job/start", methods=["POST"])
def start_job():
    global job_state
    with job_lock:
        if job_state["running"]:
            return jsonify({"error": "A job is already running"}), 409

    data       = request.json
    direction  = data.get("direction")
    record_ids = data.get("record_ids", [])

    if direction not in ("DR", "HO"):
        return jsonify({"error": "direction must be DR or HO"}), 400

    # Show Windows credential popup — blocks here until user clicks OK/Cancel
    ok, username_or_err = prompt_and_cache_credential()
    if not ok:
        return jsonify({"error": username_or_err}), 401

    all_records = load_records()
    to_change = (
        [r for r in all_records if str(r.get("id")) in [str(x) for x in record_ids]]
        if record_ids else all_records
    )

    with job_lock:
        job_state = {
            "running":     True,
            "direction":   direction,
            "total":       len(to_change),
            "done":        0,
            "results":     [],
            "started_at":  datetime.now().isoformat(),
            "finished_at": None,
            "logged_user": username_or_err,
        }

    threading.Thread(
        target=run_bulk_job,
        args=(direction, to_change, username_or_err),
        daemon=True
    ).start()

    return jsonify({"ok": True, "total": len(to_change), "logged_as": username_or_err})

@app.route("/api/job/status", methods=["GET"])
def job_status():
    with job_lock:
        return jsonify(dict(job_state))

@app.route("/api/job/abort", methods=["POST"])
def abort_job():
    with job_lock:
        job_state["running"] = False
    clear_credential_cache()
    return jsonify({"ok": True})

@app.route("/api/history", methods=["GET"])
def history():
    return jsonify(load_change_log())


@app.route("/api/records/live", methods=["POST"])
def live_dns():
    """
    Query the DNS server for the current A-record IP of each record.
    Accepts optional JSON body: { "record_ids": [...] }
    Uses the DPAPI-cached credential if present, otherwise tries with
    the current Windows session (Kerberos / domain auth).
    Returns a list of { id, record_name, zone, current_ip, error }.
    """
    data = request.json or {}
    record_ids = data.get("record_ids", [])
    all_records = load_records()

    if record_ids:
        targets = [r for r in all_records if str(r.get("id")) in [str(x) for x in record_ids]]
    else:
        targets = all_records

    results = []

    for rec in targets:
        zone        = rec.get("zone", "")
        record_name = rec.get("record_name", "")

        # Try with cached credential first; fall back to implicit domain auth
        ps = f"""
$ErrorActionPreference = 'Stop'
$credPath = [System.Environment]::ExpandEnvironmentVariables('%TEMP%\\dns_dr_cred.xml')
try {{
    if (Test-Path $credPath) {{
        $cred = Import-Clixml -Path $credPath
        $rec = Invoke-Command -ComputerName '{DNS_SERVER}' -Credential $cred -ScriptBlock {{
            param($z,$n)
            Get-DnsServerResourceRecord -ZoneName $z -Name $n -RRType A -ErrorAction Stop
        }} -ArgumentList '{zone}','{record_name}'
    }} else {{
        $rec = Get-DnsServerResourceRecord -ComputerName '{DNS_SERVER}' -ZoneName '{zone}' -Name '{record_name}' -RRType A -ErrorAction Stop
    }}
    $ip = ($rec | Select-Object -First 1).RecordData.IPv4Address.ToString()
    Write-Output "IP:$ip"
}} catch {{
    Write-Output "ERROR:$($_.Exception.Message)"
}}
"""
        try:
            result = subprocess.run(
                ["powershell", "-NoProfile", "-NonInteractive", "-Command", ps],
                capture_output=True, text=True, timeout=20
            )
            out = (result.stdout + result.stderr).strip()
            if out.startswith("IP:"):
                results.append({
                    "id":          rec.get("id"),
                    "app_name":    rec.get("app_name"),
                    "record_name": record_name,
                    "zone":        zone,
                    "ho_ip":       rec.get("ho_ip"),
                    "dr_ip":       rec.get("dr_ip"),
                    "current_ip":  out.replace("IP:", "").strip(),
                    "error":       None,
                })
            else:
                results.append({
                    "id":          rec.get("id"),
                    "app_name":    rec.get("app_name"),
                    "record_name": record_name,
                    "zone":        zone,
                    "ho_ip":       rec.get("ho_ip"),
                    "dr_ip":       rec.get("dr_ip"),
                    "current_ip":  None,
                    "error":       out.replace("ERROR:", "").strip() or "Unknown error",
                })
        except subprocess.TimeoutExpired:
            results.append({
                "id":          rec.get("id"),
                "app_name":    rec.get("app_name"),
                "record_name": record_name,
                "zone":        zone,
                "ho_ip":       rec.get("ho_ip"),
                "dr_ip":       rec.get("dr_ip"),
                "current_ip":  None,
                "error":       "Timeout querying DNS server",
            })
        except Exception as e:
            results.append({
                "id":          rec.get("id"),
                "app_name":    rec.get("app_name"),
                "record_name": record_name,
                "zone":        zone,
                "ho_ip":       rec.get("ho_ip"),
                "dr_ip":       rec.get("dr_ip"),
                "current_ip":  None,
                "error":       str(e),
            })

    return jsonify(results)


if __name__ == "__main__":
    os.makedirs("data", exist_ok=True)
    os.makedirs("logs", exist_ok=True)
    print(f"\n{'='*50}")
    print(f"  DNS DR Control Panel")
    print(f"  Dashboard : http://localhost:{BIND_PORT}  (this PC only)")
    print(f"  DNS Server: {DNS_SERVER}  (remote target)")
    print(f"{'='*50}\n")
    app.run(host=BIND_HOST, port=BIND_PORT, debug=False)
