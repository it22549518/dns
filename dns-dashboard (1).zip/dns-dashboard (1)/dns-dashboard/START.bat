@echo off
title DNS DR Control Panel
echo ============================================
echo  DNS DR CONTROL PANEL
echo ============================================
echo.
echo  Dashboard : http://localhost:5000  (this PC only)
echo  DNS Server: 192.168.13.80  (remote target)
echo.
echo  When you fire a DR or HO switch, a Windows
echo  credential popup will appear on this screen.
echo  Enter:  .\user1  and the server password.
echo  The password never touches this script.
echo ============================================
echo.

python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python not found. Install from python.org
    pause & exit /b 1
)

pip install -r requirements.txt --quiet
if not exist "data" mkdir data
if not exist "logs" mkdir logs

start "" http://localhost:5000
python app.py
pause
